﻿using System;
using AngleSharp.Html.Dom;

namespace ParserConsole.Core
{
    public interface IParser<T> where T : class  //класс реализующие этот интерфейс смогут возвращаться данные любого ссылочного типа
    {
        T Parse(IHtmlDocument document);  
    }
}
