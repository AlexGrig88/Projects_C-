﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParserConsole.Core.Habr
{
    public class AvitoSettings : IParserSettings
    {
        public string BaseUrl { get; set; } = "https://www.avito.ru/rostov-na-donu/tovary_dlya_kompyutera";
        public string Postfix { get; set; } = "monitory-ASgBAgICAUTGB4Bo?cd=1&p={CurrentId}";
        public int StartPoint { get; set; }
        public int EndPoint { get; set; }

        public AvitoSettings(int start, int end)
        {
            StartPoint = start;
            EndPoint = end;
        }
    }
}
