﻿using AngleSharp.Dom;
using AngleSharp.Html.Dom;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParserConsole.Core.Habr
{
    public class AvitoParser : IParser<string[]>
    {
        public string[] Parse(IHtmlDocument document)
        {
            //Для хранения заголовков
            List<string> list = new List<string>();
            //Здесь мы получаем заголовки
            /*IEnumerable<IElement> items = document.QuerySelectorAll("a")
                .Where(item => item.ClassName != null && item.ClassName.Contains("post__title_link"));*/

            IEnumerable<IElement> items = document.QuerySelectorAll("span")
                .Where(item => item.GetAttribute("itemprop") != null && item.GetAttribute("itemprop").Contains("name"));

            int countFirstFree = 0;
            foreach (var item in items)
            {
              
                
                    
                        list.Add(item.TextContent);  //Добавляем заголовки в коллекцию.
                        countFirstFree++;
                  
            }
          
            return list.ToArray();
        }
    }
}
