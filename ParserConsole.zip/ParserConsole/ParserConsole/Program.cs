﻿using ParserConsole.Core;
using ParserConsole.Core.Habr;
using System;
using System.Threading;

namespace ParserConsole
{
    class Program
    {
        static void Main(string[] args)
        {
           var parser_habr = new ParserWorker<string[]>(new AvitoParser()); 
            
           parser_habr.Settings = new AvitoSettings(1, 1); //настройка страниц для парсинга
           parser_habr.OnNewData += Parser_OnNewData;
           
            parser_habr.Start();

            while (parser_habr.IsActive) { }


            Console.ReadLine();
        }

        private static void Parser_OnNewData(object o, string[] str)
        {
            Console.WriteLine(new String('=', 60));
            int counter = 1;
            foreach (var item in str)
            {
                /* Данные 3 строки иногда парсятся с заголовками - Необходимо избавиться!
                 *  - Ростов-на-Дону
                    - Бытовая электроника
                    - Товары для компьютера
                   using for()
                 */
                Console.WriteLine($"{counter++}){item}");
            }
        }
    }
}
