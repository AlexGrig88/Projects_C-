﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog_Grig_Ver2._0.Models.Comments
{
    public class SubComment : Comment
    {
        public int MainCommentId { get; set; }  //ссылка на id главного коммента
    }
}
