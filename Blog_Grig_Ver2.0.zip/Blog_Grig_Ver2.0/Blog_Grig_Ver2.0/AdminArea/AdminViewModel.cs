﻿using Blog_Grig_Ver2._0.Data.Repository;
using Blog_Grig_Ver2._0.Models;
using Blog_Grig_Ver2._0.Models.Comments;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog_Grig_Ver2._0.AdminArea
{
    public class AdminViewModel
    {
        public IEnumerable<Post> PostsForAdmin { get; set; }
        public IEnumerable<Comment> AllComments { get; set; }

    }
}
