﻿
$(function () {

    var location = window.location.href;
    var cur_url = '/' + location.split('/').pop();
    cur_url = '/?category=' + cur_url.split('=').pop();

    $('#menu ul li').each(function () {
        var link = $(this).find('a').attr('href');

        if (cur_url == link) {
            $(this).addClass('fixCategory');
        }
        
    });
});