﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog_Grig_Ver2._0.Helpers
{
    public static class PageHelper
    {
        //Метод для пагинации
        public static IEnumerable<int> PageNumbers(int pageNumber, int pageCount)
        {
            
            if (pageCount > 5)
            {
                // диапазон отображаемых страниц будует равен 5
                // +2 от левого края и -2 от правого
                int midPoint = pageNumber < 3 ? 3
                    : pageNumber > pageCount - 2 ? pageCount - 2
                    : pageNumber;

                for (int i = midPoint - 2; i <= midPoint + 2; i++)
                {
                    yield return i;
                }
            }
            else
            {
                for (int i = 1; i <= pageCount; i++)
                {
                    yield return i;
                }
            }
            
        }
    }
}
