﻿using Blog_Grig_Ver2._0.Helpers;
using Blog_Grig_Ver2._0.Models;
using Blog_Grig_Ver2._0.Models.Comments;
using Blog_Grig_Ver2._0.ViewModels;
using Microsoft.EntityFrameworkCore;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Blog_Grig_Ver2._0.Data.Repository
{
    public class Repository : IRepository
    {

        private AppDbContext dbContext;

        public Repository(AppDbContext ctx)
        {
            dbContext = ctx;
        }

        public void AddPost(Post post)
        {
            dbContext.Posts.Add(post);

        }


        public List<Post> GetAllPosts() => dbContext.Posts.ToList();


        public IndexViewModel GetAllPosts(
            int pageNumber, 
            string category,
            string search)
        {
            //Func<Post, bool> InCategory = (post) => { return post.Category.ToLower().Equals(category.ToLower()); }; не работает

            int postsCountOfPage = 3;                //коолличество постов на одной странице
            int skipAmount = postsCountOfPage * (pageNumber - 1);
            int capacity = skipAmount + postsCountOfPage; 

            var query = dbContext.Posts.AsNoTracking().AsQueryable();
                    

            if (!String.IsNullOrEmpty(category))
                query = query.Where(post => post.Category.ToLower().Equals(category.ToLower()));

            if (!String.IsNullOrEmpty(search))
                query = query.Where(x => x.Title.Contains(search)
                                      || x.Body.Contains(search)
                                      || x.Description.Contains(search));

            var postsCount = query.Count();
            int pageCount = (int)Math.Ceiling((double)postsCount / postsCountOfPage);

            return new IndexViewModel
            {
                PageNumber = pageNumber,
                PageCount = pageCount,
                NextPage = postsCount > capacity,
                PagesForPagination = PageHelper.PageNumbers(pageNumber, pageCount).ToList(),
                Category = category,
                Search = search,
                Posts = query
                    .Skip(skipAmount)
                    .Take(postsCountOfPage)
                    .ToList()
            };

        }
        


        public Post GetPost(int id)
        {
            //Мы получаем объект поста, часть которого берётся из таблицы б/д Posts
            //другие 2 части из таблиц MainComments и SubComments, а т.к. Posts не
            //связана с ними (поле типа List<> не отображается в б/д), то используем
            //расширяющий метод Include
            return dbContext.Posts
            .Include(p => p.MainComments)
                .ThenInclude(mc => mc.SubComments)
            .FirstOrDefault(p => p.Id == id);
        }

        public void RemovePost(int id)
        {
            dbContext.Posts.Remove(GetPost(id));
        }

        public void UpdatePost(Post post)
        {
            dbContext.Posts.Update(post);
        }

        public async Task<bool> SaveChangesAsync()
        {
            if (await dbContext.SaveChangesAsync() > 0)
            {
                return true;
            }
            return false;
        }

        public void AddSubComment(SubComment comment)
        {
            dbContext.SubComments.Add(comment);
        }

        
    }
}
